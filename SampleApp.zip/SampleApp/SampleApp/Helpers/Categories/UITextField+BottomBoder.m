//
//  UITextField+BottomBoder.m
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "UITextField+BottomBoder.h"

@implementation UITextField (BottomBoder)

- (void)addBottomBoder{
    CALayer *bottomEmailTextFieldBorder = [CALayer layer];
    bottomEmailTextFieldBorder.frame = CGRectMake(0.0f, self.frame.size.height - 1.0f, self.frame.size.width, 1.0f);
    bottomEmailTextFieldBorder.backgroundColor = [UIColor lightGrayColor].CGColor;
    [self.layer addSublayer:bottomEmailTextFieldBorder];
}

@end
