//
//  Constants.h
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define SEG_LOGIN_TO_SIGNUP     @"SegLoginToSignUp"
#define SEG_LOGIN_TO_MAIN       @"SegLoginToMain"
#define SEG_MAIN_TO_ABOUT       @"SegMainToAbout"

#define BASE_CONNECTION         @"http://54.255.201.10:9000/"
#define SIGNUP                  @"create"
#define LOGIN                   @"auth/signin"
#define USERS                   @"users"

#endif /* Constants_h */
