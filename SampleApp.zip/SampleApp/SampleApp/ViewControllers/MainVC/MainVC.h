//
//  MainVC.h
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CarbonKit.h"
#import "LoginInfo.h"

@interface MainVC : UIViewController{
    NSArray *items;
    CarbonTabSwipeNavigation *carbonTabSwipeNavigation;
    
    __weak IBOutlet NSLayoutConstraint *lcLeadingView;
    __weak IBOutlet UIView *vwMenu;
    
    __weak IBOutlet UITableView *tbvMenu;
        
    NSArray *arrMenu;
}

@property (nonatomic, strong) LoginInfo *currentLoginInfo;

@end
