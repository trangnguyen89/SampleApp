//
//  MainVC.m
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "MainVC.h"
#import "UserVC.h"
#import "Constants.h"

@interface MainVC ()

@end

@implementation MainVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUpUI];
    [self setUpData];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Main Functions
- (void)setUpUI{
    items = @[
              @"USERS",
              @"SETTING"
              ];
    
    carbonTabSwipeNavigation = [[CarbonTabSwipeNavigation alloc] initWithItems:items delegate:self];
    [carbonTabSwipeNavigation insertIntoRootViewController:self];
    
    //modify horizontal scrolling same markup
    [self style];
}

- (void)setUpData{
    lcLeadingView.constant = -self.view.frame.size.width;
    [self.view layoutIfNeeded];
    
    arrMenu = @[@"Main",@"About"];
    [tbvMenu reloadData];

}

- (void)style {
    UIColor *color = [UIColor colorWithRed:77.0f/255.0f green:172.0f/255.0f blue:156.0f/255.0f alpha:1];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barTintColor = color;
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackTranslucent;
    
    carbonTabSwipeNavigation.toolbar.translucent = NO;
    carbonTabSwipeNavigation.toolbar.barTintColor = color;
    [carbonTabSwipeNavigation setIndicatorColor:[UIColor colorWithRed:255.0f/255.0f green:237.0f/255.0f blue:25.0f/255.0f alpha:1.0]];
    [carbonTabSwipeNavigation setTabExtraWidth:30];
    [carbonTabSwipeNavigation.carbonSegmentedControl setWidth:self.view.frame.size.width/2 forSegmentAtIndex:0];
    [carbonTabSwipeNavigation.carbonSegmentedControl setWidth:self.view.frame.size.width/2 forSegmentAtIndex:1];
    
    // Customize segmented control
    [carbonTabSwipeNavigation setNormalColor:[[UIColor whiteColor] colorWithAlphaComponent:0.6]
                                        font:[UIFont boldSystemFontOfSize:14]];
    [carbonTabSwipeNavigation setSelectedColor:[UIColor whiteColor] font:[UIFont boldSystemFontOfSize:14]];
}

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}
#pragma mark - CarbonTabSwipeNavigationDelegate
- (nonnull UIViewController *)carbonTabSwipeNavigation:
(nonnull CarbonTabSwipeNavigation *)carbontTabSwipeNavigation
                                 viewControllerAtIndex:(NSUInteger)index {
    switch (index) {
        case 0:{
            UserVC *vcUser = (UserVC*)[self.storyboard instantiateViewControllerWithIdentifier:@"UserVC"];
            vcUser.currentLoginInfo = self.currentLoginInfo;
            
            return vcUser;
        }
            
        case 1:
            return [self.storyboard instantiateViewControllerWithIdentifier:@"SettingVC"];
            
        default:
            return [self.storyboard instantiateViewControllerWithIdentifier:@"UserVC"];
    }
}

#pragma mark - Selectors

- (IBAction)onMenuTap:(id)sender {
    [UIView animateWithDuration:1
                     animations:^{
                         if(lcLeadingView.constant == 0){
                             lcLeadingView.constant = -self.view.frame.size.width;
                             vwMenu.hidden = YES;
                             [self.view sendSubviewToBack:vwMenu];


                         }else{
                             lcLeadingView.constant = 0;
                             vwMenu.hidden = NO;
                             [self.view bringSubviewToFront:vwMenu];

                         }
                         
                         [self.view layoutIfNeeded];

                     }];
}

- (IBAction)onLogoutTap:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma mark - UITableViewDatasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"ID_MenuCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text = arrMenu[indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        [self onMenuTap:nil];
    }else{
        [self onMenuTap:nil];
        [self performSegueWithIdentifier:SEG_MAIN_TO_ABOUT sender:nil];
    }
}


@end
