//
//  UserVC.m
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "UserVC.h"
#import "UserCustomCell.h"
#import "MBProgressHUD.h"


@interface UserVC ()

@end

@implementation UserVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self getUserList];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Init Functions
- (Connections *)connection{
    if(_connection == nil){
        _connection = [[Connections alloc] init];
    }
    
    return _connection;
}

#pragma mark - Main Functions
- (void)getUserList{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self.connection getUserListWithKeyword:@"m" token:self.currentLoginInfo.token withSuccess:^(NSMutableArray *users) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        arrUser = users;
        [self.tbvUser reloadData];
        
    } withFailure:^(NSError *error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
}

#pragma mark - UITableViewDelegate & Datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arrUser.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"ID_UserCustomCell";
    UserCustomCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(arrUser.count>indexPath.row){
        [cell updateUser:arrUser[indexPath.row]];
    }
    return cell;
}

@end
