//
//  UserVC.h
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Connections.h"
#import "LoginInfo.h"

@interface UserVC : UIViewController<UIGestureRecognizerDelegate>{
    
    NSMutableArray *arrUser;
}

@property (weak, nonatomic) IBOutlet UITableView *tbvUser;

@property (nonatomic, strong) Connections *connection;
@property (nonatomic, strong) LoginInfo *currentLoginInfo;

@end
