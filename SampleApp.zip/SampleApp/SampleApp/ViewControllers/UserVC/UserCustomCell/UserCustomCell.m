//
//  UserCustomCell.m
//  SampleApp
//
//  Created by Trang Nguyen on 8/20/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "UserCustomCell.h"
#import <SDWebImage/UIImageView+WebCache.h>

@implementation UserCustomCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [imvAvatar.layer setCornerRadius:imvAvatar.frame.size.height/2];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)updateUser:(User *)user{
    [imvAvatar sd_setImageWithURL:[NSURL URLWithString:user.avatar]];
    [lblName setText:user.name];
    [lblEmail setText:user.email];
}
@end
