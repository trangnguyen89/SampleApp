//
//  UserCustomCell.h
//  SampleApp
//
//  Created by Trang Nguyen on 8/20/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"

@interface UserCustomCell : UITableViewCell{
    
    __weak IBOutlet UIImageView *imvAvatar;
    __weak IBOutlet UILabel *lblName;
    __weak IBOutlet UILabel *lblEmail;
    
}
- (void)updateUser:(User *)user;
@end
