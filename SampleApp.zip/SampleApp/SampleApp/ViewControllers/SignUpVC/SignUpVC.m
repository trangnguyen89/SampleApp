//
//  SignUpVC.m
//  SampleApp
//
//  Created by Admin on 8/18/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "SignUpVC.h"
#import "UITextField+BottomBoder.h"
#import "MBProgressHUD.h"

@interface SignUpVC ()

@end

@implementation SignUpVC

- (void)viewDidLoad {
    [super viewDidLoad];
    //Call to modify UI to make it's same MarkUp
    [self setUpUI];
    //add Observers such as keyboard observer, etc
    [self addObserver];
    //init value for some parameters
    [self setUpData];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Main Functions
- (void)setUpUI{
    [txtPassword addBottomBoder];
    [txtEmail addBottomBoder];
    [txtName addBottomBoder];
}

- (void)setUpData{
    keyboardSize = CGSizeZero;
}

- (void)addObserver{
    // register notification for keyboard will show
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:self.view.window];
    // register notification for keyboard will hide
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:self.view.window];
}

//move controls view up to keyboard
- (void)moveViewUpToKeyboard{
    if(keyboardSize.height > 0){
        //1. convert controls frame base on self.view
        CGRect rectControlsCoverToSuperView = [self.view convertRect:vwControlsView.frame toView:scvSignUp];
        
        
        if ( keyboardSize.height > rectControlsCoverToSuperView.origin.y) {
            //2. caculate height of keyboard size with controls cover frame to know how height to moving
            float heightBetweenControlsCoverWithKeyboard = keyboardSize.height - rectControlsCoverToSuperView.origin.y;
            float heightAllItemAfterMoving = heightBetweenControlsCoverWithKeyboard + rectControlsCoverToSuperView.size.height + rectControlsCoverToSuperView.origin.y + [UIApplication sharedApplication].statusBarFrame.size.height;
            
            float heightMovingViewBaseSuperView = heightBetweenControlsCoverWithKeyboard - (heightAllItemAfterMoving - self.view.frame.size.height);
            //3. check if it's height more than self.view screen (such as iPhone 4)
            if( heightAllItemAfterMoving > self.view.frame.size.height){
                if(heightMovingViewBaseSuperView > 0){
                    //4. just move control view on top of self.view screen
                    [scvSignUp setContentOffset:CGPointMake(0.0f, heightMovingViewBaseSuperView) animated:YES];
                }
                
            }else{
                //5. move control view up to keyboard
                [scvSignUp setContentOffset:CGPointMake(0.0f,heightBetweenControlsCoverWithKeyboard ) animated:YES];
            }
            
        }
        
    }
}

//return controls view to defaut
- (void)moveViewDownToDefault{
    [scvSignUp setContentOffset:CGPointZero animated:YES];
    [self.view endEditing:YES];
}

#pragma mark - Selectors
- (void)keyboardWillShow:(NSNotification *)notification{
    NSDictionary* userInfo = [notification userInfo];
    // get the size of the keyboard
    keyboardSize = [[userInfo objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    [self moveViewUpToKeyboard];
}

- (void)keyboardWillHide:(NSNotification *)nofification{
    
}

- (IBAction)onOutsizeTap:(id)sender {
    [self moveViewDownToDefault];
}

- (IBAction)onCreateAccountTap:(id)sender {
    if([txtEmail.text isEqualToString:@""] || [txtPassword.text isEqualToString:@""] || [txtName.text isEqualToString:@""]){
        
    }else{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        [self.connection createNewAccountWithName:txtName.text email:txtEmail.text password:txtPassword.text withSuccess:^(User *user) {
            
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            [self.navigationController popViewControllerAnimated:YES];
            
        } withFailure:^(NSError *error) {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            
        }];
    }
    
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self moveViewUpToKeyboard];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self moveViewDownToDefault];
    return YES;
}

#pragma mark - Init Functions
- (Connections *)connection{
    if(_connection == nil){
        _connection = [[Connections alloc] init];
    }
    
    return _connection;
}

@end
