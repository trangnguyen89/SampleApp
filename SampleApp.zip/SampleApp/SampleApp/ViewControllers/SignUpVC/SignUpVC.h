//
//  SignUpVC.h
//  SampleApp
//
//  Created by Admin on 8/18/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Connections.h"

@interface SignUpVC : UIViewController{
    
    
    __weak IBOutlet UITextField *txtEmail;
    __weak IBOutlet UITextField *txtName;
    __weak IBOutlet UITextField *txtPassword;
    
    __weak IBOutlet UIScrollView *scvSignUp;
    
    
    __weak IBOutlet UIView *vwControlsView;
    
    CGSize keyboardSize;

}

@property (nonatomic, strong) Connections *connection;

@end
