//
//  LoginVC.h
//  SampleApp
//
//  Created by Admin on 8/18/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Connections.h"

@interface LoginVC : UIViewController{
    
    
    __weak IBOutlet UITextField *txtEmail;
    __weak IBOutlet UITextField *txtPassword;
    
    __weak IBOutlet UIScrollView *scvLogin;
    
    __weak IBOutlet UIView *vwControlsCover;
    
    CGSize keyboardSize;
    LoginInfo *currentLoginInfo;
    
}

@property (nonatomic, strong) Connections *connection;



@end
