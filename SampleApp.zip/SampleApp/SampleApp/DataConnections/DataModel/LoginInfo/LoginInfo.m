//
//  LoginInfo.m
//  SampleApp
//
//  Created by Trang Nguyen on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "LoginInfo.h"

@implementation LoginInfo

@end
