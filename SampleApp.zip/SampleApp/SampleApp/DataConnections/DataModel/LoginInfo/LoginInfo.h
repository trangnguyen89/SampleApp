//
//  LoginInfo.h
//  SampleApp
//
//  Created by Trang Nguyen on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "JSONModel.h"
#import "User.h"

@interface LoginInfo : JSONModel
@property (nonatomic, strong) NSString *token;
@property (nonatomic, strong) User *user;
@end
