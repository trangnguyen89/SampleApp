//
//  User.m
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "User.h"

@implementation User

@end
