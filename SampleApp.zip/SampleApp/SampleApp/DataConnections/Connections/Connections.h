//
//  Connections.h
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"
#import "LoginInfo.h"

@interface Connections : NSObject
- (void)createNewAccountWithName:(NSString*)name email:(NSString *)email password:(NSString*)password withSuccess:(void (^) (User *user))success withFailure:(void (^) (NSError *error))failure;
- (void)loginWithEmail:(NSString *)email password:(NSString *)password withSuccess:(void (^) (LoginInfo *loginInfo))success withFailure:(void (^) (NSError *error))failure;
- (void)getUserListWithKeyword:(NSString *)keyword token:(NSString *)token withSuccess:(void (^) (NSMutableArray *users))success withFailure:(void (^) (NSError *error))failure;
@end
