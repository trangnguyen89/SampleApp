//
//  Connections.m
//  SampleApp
//
//  Created by Admin on 8/19/16.
//  Copyright © 2016 Admin. All rights reserved.
//

#import "Connections.h"
#import "AFNetworking.h"
#import "Constants.h"

@implementation Connections

//Signup request
- (void)createNewAccountWithName:(NSString*)name email:(NSString *)email password:(NSString*)password withSuccess:(void (^) (User *user))success withFailure:(void (^) (NSError *error))failure{

    NSDictionary *params= @{
                            @"name":name,
                            @"email":email,
                            @"password":password
                            };
    
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager POST:[NSString stringWithFormat:@"%@%@",BASE_CONNECTION,SIGNUP] parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"response : %@",responseObject);
        User *user = [[User alloc] initWithDictionary:responseObject error:nil];
        success(user);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error : %@",error);
        failure(error);
    }];
}

//Login request
- (void)loginWithEmail:(NSString *)email password:(NSString *)password withSuccess:(void (^) (LoginInfo *loginInfo))success withFailure:(void (^) (NSError *error))failure{
    NSDictionary *params= @{
                            @"email":email,
                            @"password":password
                            };
    
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager POST:[NSString stringWithFormat:@"%@%@",BASE_CONNECTION,LOGIN] parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"response : %@",responseObject);
        LoginInfo *info = [[LoginInfo alloc] initWithDictionary:responseObject error:nil];
        success(info);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error : %@",error);
        failure(error);
    }];
}

//Get User List request
- (void)getUserListWithKeyword:(NSString *)keyword token:(NSString *)token withSuccess:(void (^) (NSMutableArray *users))success withFailure:(void (^) (NSError *error))failure{
    
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:[NSString stringWithFormat:@"%@ %@",keyword,token] forHTTPHeaderField:@"Authorization"];

    [manager GET:[NSString stringWithFormat:@"%@%@",BASE_CONNECTION,USERS] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if([responseObject isKindOfClass:[NSArray class]]){
            NSMutableArray *arrUser = [[NSMutableArray alloc] init];
            
            NSArray *arrUserDict = (NSArray *)responseObject;
            for(NSDictionary *dict in arrUserDict){
                User *user = [[User alloc] initWithDictionary:dict error:nil];
                [arrUser addObject:user];
            }
            
            success(arrUser);
        }
        
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

@end
